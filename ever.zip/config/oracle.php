<?php

return [
    'oracle' => [
        'driver' => 'oracle',
        'host' => '192.168.7.15',
        'port' => '1521',
        'database' => 'orclaz',
        'username' => 'regent',
        'password' => 'regentaz2016',
        'schema' => '',
        'charset' => 'AL32UTF8',
        'prefix' => '',
    ],
];
