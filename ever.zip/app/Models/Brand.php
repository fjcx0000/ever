<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Brand extends Model
{
    public $incrementing = false;
    public $primaryKey = 'brand_id';
}
