<?php
/**
 * Created by PhpStorm.
 * User: think
 * Date: 30/04/2017
 * Time: 12:03 AM
 */

namespace App\Exceptions;


class StorageException extends \Exception
{

}