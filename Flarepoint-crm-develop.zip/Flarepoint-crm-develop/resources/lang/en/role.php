<?php

return [
    'headers' =>  [
        'name' => 'Role name',
        'description' => 'Description',
        'action' => 'Action',
        'add_new' => 'Add new role',
        'delete' => 'Delete',
        'roles' => 'Role Managment',
    ],
];