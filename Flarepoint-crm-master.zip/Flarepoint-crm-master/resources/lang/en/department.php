<?php

return [
    'headers' =>  [
        'title' => 'Title',
        'description' => 'Description',
        'action' => 'Action',
    ],

    'titles' => [
    	'delete' => 'Delete',
    	'create' => 'Create New Department',
    	'name' => 'Department name',
    	'description' => 'Department description'
    ],

];